let carrinho = [];
let total = 0;

function adicionarAoCarrinho(nome, preco) {
  carrinho.push({ nome, preco });
  total += preco;
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const lista = document.getElementById('itens-carrinho');
  lista.innerHTML = '';
  carrinho.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.nome} - Kz ${item.preco}`;
    lista.appendChild(li);
  });
  document.getElementById('total').textContent = total;
}

document.getElementById('formulario-contacto').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Mensagem enviada com sucesso!');
  this.reset();
});
